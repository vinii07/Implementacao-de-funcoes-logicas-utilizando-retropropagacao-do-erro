# Fundamentação Teórica

## Redes Neurais Artificiais e o Algoritmo de Backpropagation

Redes Neurais Artificiais (RNAs) são modelos computacionais inspirados na estrutura e funcionamento do cérebro humano, projetadas para reconhecer padrões e aprender a partir de dados. Uma das arquiteturas mais comuns é o Perceptron Multicamadas (MLP), que consiste em uma camada de entrada, uma ou mais camadas ocultas e uma camada de saída. Para treinar essas redes, o algoritmo de **Backpropagation (Retropropagação do Erro)** é amplamente utilizado.

O Backpropagation é um método de treinamento supervisionado que ajusta os pesos e vieses de uma rede neural para minimizar o erro entre a saída prevista da rede e a saída desejada. Ele opera em duas fases principais: a fase *forward* (propagação para frente) e a fase *backward* (propagação para trás).

### Fase Forward (Propagação para Frente)

Nesta fase, os dados de entrada são alimentados na rede e propagados através das camadas até a camada de saída. Para cada neurônio em uma camada, a entrada líquida ($net_j$) é calculada como a soma ponderada das saídas dos neurônios da camada anterior, mais um viés ($b_j$):

$$net_j = \sum_{i=1}^{n} w_{ij}o_i + b_j$$

Onde:
- $w_{ij}$ são os pesos conectando o neurônio $i$ da camada anterior ao neurônio $j$ da camada atual.
- $o_i$ é a saída do neurônio $i$ da camada anterior.
- $b_j$ é o viés do neurônio $j$.

Em seguida, uma **função de ativação** ($f$) é aplicada à entrada líquida para produzir a saída do neurônio ($o_j$):

$$o_j = f(net_j)$$

As funções de ativação introduzem não-linearidade na rede, permitindo que ela aprenda relações complexas nos dados. As funções de ativação solicitadas para este trabalho são:

1.  **Sigmóide Binária**:
    $$f(x) = \frac{1}{1+e^{-x}}$$
    Sua derivada é: $f'(x) = f(x)(1 - f(x))$

2.  **Sigmóide Bipolar**:
    $$f(x) = \frac{2}{1+e^{-x}} - 1$$
    Sua derivada é: $f'(x) = \frac{1}{2}(1 - f(x)^2)$

3.  **Tangente Hiperbólica (tanh)**:
    $$f(x) = \tanh(x) = \frac{e^x - e^{-x}}{e^x + e^{-x}}$$
    Sua derivada é: $f'(x) = 1 - \tanh^2(x) = 1 - f(x)^2$

### Função de Custo (Erro)

Após a fase forward, o erro da rede é calculado utilizando uma **função de custo**. Para problemas de classificação e regressão, a **Erro Quadrático Médio (MSE)** é comumente utilizada. Para um único padrão de treinamento, o erro é:

$$E = \frac{1}{2}\sum_{j=1}^{m} (d_j - o_j)^2$$

Onde:
- $d_j$ é a saída desejada (target) para o neurônio $j$ da camada de saída.
- $o_j$ é a saída real do neurônio $j$ da camada de saída.
- $m$ é o número de neurônios na camada de saída.

O objetivo do treinamento é minimizar essa função de custo.

### Fase Backward (Retropropagação do Erro e Atualização de Pesos)

Nesta fase, o erro é propagado de volta através da rede, e os pesos e vieses são ajustados usando o método do **gradiente descendente**. O ajuste de cada peso ($w_{ij}$) é proporcional ao gradiente da função de custo em relação a esse peso, multiplicado por uma **taxa de aprendizado** ($\eta$):

$$\Delta w_{ij} = -\eta \frac{\partial E}{\partial w_{ij}}$$

Para calcular $\frac{\partial E}{\partial w_{ij}}$, aplica-se a regra da cadeia. O cálculo difere para a camada de saída e para as camadas ocultas.

#### Para a Camada de Saída:

O erro local ($\delta_j$) para um neurônio $j$ na camada de saída é:

$$\delta_j = (d_j - o_j) \cdot f'(net_j)$$

E a atualização do peso é:

$$\Delta w_{ij} = \eta \cdot \delta_j \cdot o_i$$

#### Para as Camadas Ocultas:

Para um neurônio $j$ em uma camada oculta, o erro local ($\delta_j$) é calculado com base nos erros dos neurônios da camada subsequente que ele influencia:

$$\delta_j = f'(net_j) \sum_{k} \delta_k w_{jk}$$

Onde:
- $\delta_k$ é o erro local do neurônio $k$ na camada subsequente.
- $w_{jk}$ é o peso conectando o neurônio $j$ ao neurônio $k$.

E a atualização do peso é a mesma:

$$\Delta w_{ij} = \eta \cdot \delta_j \cdot o_i$$

Os vieses são atualizados de forma semelhante, considerando-os como pesos de uma entrada constante igual a 1.

Este processo iterativo de forward e backward é repetido por um número definido de épocas ou até que o erro da rede atinja um valor tolerável.

# Modelagem do Problema

## Funções Lógicas e a Necessidade de Redes Multicamadas

Para demonstrar a capacidade das Redes Neurais Artificiais em aprender padrões complexos, este trabalho foca na implementação de funções lógicas básicas. As funções lógicas são operações fundamentais na computação e na lógica booleana, que recebem uma ou mais entradas binárias (0 ou 1) e produzem uma saída binária.

### Funções Lógicas a Serem Implementadas

As principais funções lógicas que serão abordadas são:

-   **AND (E)**: A saída é 1 apenas se todas as entradas forem 1. Caso contrário, a saída é 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 0     |
| 1         | 0         | 0     |
| 1         | 1         | 1     |

-   **OR (OU)**: A saída é 1 se pelo menos uma das entradas for 1. A saída é 0 apenas se todas as entradas forem 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 1     |

-   **XOR (OU Exclusivo)**: A saída é 1 se as entradas forem diferentes. A saída é 0 se as entradas forem iguais.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 0     |

-   **NAND (NÃO E)**: É o inverso da função AND. A saída é 0 apenas se todas as entradas forem 1. Caso contrário, a saída é 1.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 1     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 0     |

-   **NOR (NÃO OU)**: É o inverso da função OR. A saída é 1 apenas se todas as entradas forem 0. Caso contrário, a saída é 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 1     |
| 0         | 1         | 0     |
| 1         | 0         | 0     |
| 1         | 1         | 0     |

### Linearidade vs. Não-Linearidade e a Necessidade de Redes Multicamadas

As funções lógicas AND e OR são **linearmente separáveis**. Isso significa que é possível traçar uma única linha (ou hiperplano em dimensões superiores) que separe perfeitamente as classes de saída (0s e 1s) no espaço de entrada. Um Perceptron simples, com apenas uma camada de neurônios, é capaz de aprender e classificar problemas linearmente separáveis.

No entanto, a função **XOR** não é linearmente separável. Não é possível traçar uma única linha que separe as saídas 0 das saídas 1 no plano cartesiano. Para resolver problemas não linearmente separáveis como o XOR, é essencial utilizar uma **rede neural multicamadas (MLP)**. A camada oculta em uma MLP permite que a rede aprenda representações mais complexas e não-lineares dos dados de entrada, transformando o espaço de entrada original em um espaço onde as classes se tornam linearmente separáveis. Essa capacidade de aprender fronteiras de decisão não-lineares é o que torna as MLPs poderosas para uma vasta gama de problemas de aprendizado de máquina.

No contexto deste trabalho, a implementação de uma MLP com uma camada intermediária será crucial para demonstrar a solução do problema XOR, que é um marco clássico na história das redes neurais.
