# Trabalho 2: Implementação de Funções Lógicas Utilizando Retropropagação do Erro

**Autor:** Manus AI

## 1. Objetivos

Este trabalho tem como objetivo proporcionar uma experiência prática com redes neurais artificiais do tipo MLP (MultiLayer Perceptron) e com o algoritmo de treinamento por retropropagação do erro (Backpropagation), por meio da reprodução dos experimentos apresentados no roteiro de referência.

## 2. Fundamentação Teórica

### 2.1. Redes Neurais Artificiais e o Algoritmo de Backpropagation

Redes Neurais Artificiais (RNAs) são modelos computacionais inspirados na estrutura e funcionamento do cérebro humano, projetadas para reconhecer padrões e aprender a partir de dados. Uma das arquiteturas mais comuns é o Perceptron Multicamadas (MLP), que consiste em uma camada de entrada, uma ou mais camadas ocultas e uma camada de saída. Para treinar essas redes, o algoritmo de **Backpropagation (Retropropagação do Erro)** é amplamente utilizado.

O Backpropagation é um método de treinamento supervisionado que ajusta os pesos e vieses de uma rede neural para minimizar o erro entre a saída prevista da rede e a saída desejada. Ele opera em duas fases principais: a fase *forward* (propagação para frente) e a fase *backward* (propagação para trás).

### 2.2. Fase Forward (Propagação para Frente)

Nesta fase, os dados de entrada são alimentados na rede e propagados através das camadas até a camada de saída. Para cada neurônio em uma camada, a entrada líquida ($net_j$) é calculada como a soma ponderada das saídas dos neurônios da camada anterior, mais um viés ($b_j$):

$$net_j = \sum_{i=1}^{n} w_{ij}o_i + b_j$$

Onde:
- $w_{ij}$ são os pesos conectando o neurônio $i$ da camada anterior ao neurônio $j$ da camada atual.
- $o_i$ é a saída do neurônio $i$ da camada anterior.
- $b_j$ é o viés do neurônio $j$.

Em seguida, uma **função de ativação** ($f$) é aplicada à entrada líquida para produzir a saída do neurônio ($o_j$):

$$o_j = f(net_j)$$

As funções de ativação introduzem não-linearidade na rede, permitindo que ela aprenda relações complexas nos dados. As funções de ativação implementadas neste trabalho são:

1.  **Sigmóide Binária**:
    $$f(x) = \frac{1}{1+e^{-x}}$$
    Sua derivada é: $f'(x) = f(x)(1 - f(x))$

2.  **Sigmóide Bipolar**:
    $$f(x) = \frac{2}{1+e^{-x}} - 1$$
    Sua derivada é: $f'(x) = \frac{1}{2}(1 - f(x)^2)$

3.  **Tangente Hiperbólica (tanh)**:
    $$f(x) = \tanh(x) = \frac{e^x - e^{-x}}{e^x + e^{-x}}$$
    Sua derivada é: $f'(x) = 1 - \tanh^2(x) = 1 - f(x)^2$

### 2.3. Função de Custo (Erro)

Após a fase forward, o erro da rede é calculado utilizando uma **função de custo**. Para problemas de classificação e regressão, a **Erro Quadrático Médio (MSE)** é comumente utilizada. Para um único padrão de treinamento, o erro é:

$$E = \frac{1}{2}\sum_{j=1}^{m} (d_j - o_j)^2$$

Onde:
- $d_j$ é a saída desejada (target) para o neurônio $j$ da camada de saída.
- $o_j$ é a saída real do neurônio $j$ da camada de saída.
- $m$ é o número de neurônios na camada de saída.

O objetivo do treinamento é minimizar essa função de custo.

### 2.4. Fase Backward (Retropropagação do Erro e Atualização de Pesos)

Nesta fase, o erro é propagado de volta através da rede, e os pesos e vieses são ajustados usando o método do **gradiente descendente**. O ajuste de cada peso ($w_{ij}$) é proporcional ao gradiente da função de custo em relação a esse peso, multiplicado por uma **taxa de aprendizado** ($\eta$):

$$\Delta w_{ij} = -\eta \frac{\partial E}{\partial w_{ij}}$$

Para calcular $\frac{\partial E}{\partial w_{ij}}$, aplica-se a regra da cadeia. O cálculo difere para a camada de saída e para as camadas ocultas.

#### Para a Camada de Saída:

O erro local ($\delta_j$) para um neurônio $j$ na camada de saída é:

$$\delta_j = (d_j - o_j) \cdot f'(net_j)$$

E a atualização do peso é:

$$\Delta w_{ij} = \eta \cdot \delta_j \cdot o_i$$

#### Para as Camadas Ocultas:

Para um neurônio $j$ em uma camada oculta, o erro local ($\delta_j$) é calculado com base nos erros dos neurônios da camada subsequente que ele influencia:

$$\delta_j = f'(net_j) \sum_{k} \delta_k w_{jk}$$

Onde:
- $\delta_k$ é o erro local do neurônio $k$ na camada subsequente.
- $w_{jk}$ é o peso conectando o neurônio $j$ ao neurônio $k$.

E a atualização do peso é a mesma:

$$\Delta w_{ij} = \eta \cdot \delta_j \cdot o_i$$

Os vieses são atualizados de forma semelhante, considerando-os como pesos de uma entrada constante igual a 1.

Este processo iterativo de forward e backward é repetido por um número definido de épocas ou até que o erro da rede atinja um valor tolerável.

## 3. Modelagem do Problema

### 3.1. Funções Lógicas e a Necessidade de Redes Multicamadas

Para demonstrar a capacidade das Redes Neurais Artificiais em aprender padrões complexos, este trabalho foca na implementação de funções lógicas básicas. As funções lógicas são operações fundamentais na computação e na lógica booleana, que recebem uma ou mais entradas binárias (0 ou 1) e produzem uma saída binária.

### 3.2. Funções Lógicas a Serem Implementadas

As principais funções lógicas que serão abordadas são:

-   **AND (E)**: A saída é 1 apenas se todas as entradas forem 1. Caso contrário, a saída é 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 0     |
| 1         | 0         | 0     |
| 1         | 1         | 1     |

-   **OR (OU)**: A saída é 1 se pelo menos uma das entradas for 1. A saída é 0 apenas se todas as entradas forem 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 1     |

-   **XOR (OU Exclusivo)**: A saída é 1 se as entradas forem diferentes. A saída é 0 se as entradas forem iguais.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 0     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 0     |

-   **NAND (NÃO E)**: É o inverso da função AND. A saída é 0 apenas se todas as entradas forem 1. Caso contrário, a saída é 1.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 1     |
| 0         | 1         | 1     |
| 1         | 0         | 1     |
| 1         | 1         | 0     |

-   **NOR (NÃO OU)**: É o inverso da função OR. A saída é 1 apenas se todas as entradas forem 0. Caso contrário, a saída é 0.

| Entrada A | Entrada B | Saída |
| :-------- | :-------- | :---- |
| 0         | 0         | 1     |
| 0         | 1         | 0     |
| 1         | 0         | 0     |
| 1         | 1         | 0     |

### 3.3. Linearidade vs. Não-Linearidade e a Necessidade de Redes Multicamadas

As funções lógicas AND e OR são **linearmente separáveis**. Isso significa que é possível traçar uma única linha (ou hiperplano em dimensões superiores) que separe perfeitamente as classes de saída (0s e 1s) no espaço de entrada. Um Perceptron simples, com apenas uma camada de neurônios, é capaz de aprender e classificar problemas linearmente separáveis.

No entanto, a função **XOR** não é linearmente separável. Não é possível traçar uma única linha que separe as saídas 0 das saídas 1 no plano cartesiano. Para resolver problemas não linearmente separáveis como o XOR, é essencial utilizar uma **rede neural multicamadas (MLP)**. A camada oculta em uma MLP permite que a rede aprenda representações mais complexas e não-lineares dos dados de entrada, transformando o espaço de entrada original em um espaço onde as classes se tornam linearmente separáveis. Essa capacidade de aprender fronteiras de decisão não-lineares é o que torna as MLPs poderosas para uma vasta gama de problemas de aprendizado de máquina.

No contexto deste trabalho, a implementação de uma MLP com uma camada intermediária será crucial para demonstrar a solução do problema XOR, que é um marco clássico na história das redes neurais.

## 4. Preparação do Ambiente

Para a execução do código, são necessárias as bibliotecas `numpy` para operações numéricas e `matplotlib` para a geração de gráficos. Ambas podem ser instaladas via `pip`:

```bash
pip install numpy matplotlib
```

## 5. Implementação das Funções de Ativação

As funções de ativação Sigmóide Binária, Sigmóide Bipolar e Tangente Hiperbólica, juntamente com suas respectivas derivadas, foram implementadas em Python utilizando a biblioteca NumPy. O código completo pode ser encontrado no arquivo `mlp_backpropagation.py`.

### 5.1. Gráficos das Funções de Ativação

A seguir, são apresentados os gráficos das funções de ativação implementadas, gerados pelo script `mlp_backpropagation.py`:

![Gráficos das Funções de Ativação](https://private-us-east-1.manuscdn.com/sessionFile/YccXVbaseyg0xtKZ0sLnsZ/sandbox/L8IDgrpb9ttvYE8i9KI87S-images_1781123721682_na1fn_L2hvbWUvdWJ1bnR1L2Z1bmNvZXNfYXRpdmFjYW8.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWWNjWFZiYXNleWcweHRLWjBzTG5zWi9zYW5kYm94L0w4SURncnBiOXR0dllFOGk5S0k4N1MtaW1hZ2VzXzE3ODExMjM3MjE2ODJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyWjFibU52WlhOZllYUnBkbUZqWVc4LnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=MuhcwxnZ5R7yB5jtcwI4M8bWEhjqWjvIA-crpJq4SlbmbZ9RWmJuANY~xbndxnrxTeyFVzqeLpgTyxwK~DfL8yAqvEJ3YKJzDMD8xxB-~~4GgKckkPz77jnN7fyLmKjU265ITuynygABcVjzqtvMo8zcIrJNs4TC7hXFYtiuEhngYArMHcX2v4DqicmoJFw~alllbsOq5dA9qpbjypyBn4pOOlWrK31s5VMAyk5H9yVZKJZKO9K-U9WBkZWQtA5phmdpn46qpT2vV0CwbglTcbd09Msqf3hd-9ZdQz8QN6sFFesuE6mtVpX5EylV~hLQ2iLK6kjwjOdDFPk~Ua26hA__)

## 6. Implementação da Rede MLP e do Algoritmo Backpropagation

A classe `MLP` foi implementada para representar a rede neural Perceptron Multicamadas. Ela inclui os métodos para a fase *forward* (propagação para frente) e *backward* (retropropagação do erro), além do método `train` para o treinamento da rede. A arquitetura da rede consiste em:

-   2 neurônios de entrada
-   1 camada intermediária (com número de neurônios variável nos experimentos)
-   1 neurônio de saída

Os pesos e vieses são inicializados aleatoriamente. A função de ativação utilizada para as camadas oculta e de saída é a sigmóide binária, conforme especificado no roteiro para o cálculo das derivadas no backpropagation.

O algoritmo de backpropagation ajusta os pesos e vieses da rede iterativamente, minimizando o erro quadrático médio entre a saída da rede e a saída desejada. A taxa de aprendizado e a tolerância de erro são parâmetros configuráveis.

O código completo da implementação da MLP e do algoritmo Backpropagation está disponível no arquivo `mlp_backpropagation.py`.

## 7. Reprodução do Experimento XOR

O problema XOR é um clássico em redes neurais devido à sua não-linearidade. Os padrões de entrada e saída para a função XOR são:

**Entradas (X):**
```
[[0, 0],
 [0, 1],
 [1, 0],
 [1, 1]]
```

**Saídas Desejadas (y):**
```
[[0],
 [1],
 [1],
 [0]]
```

Para a reprodução do experimento XOR, a MLP foi configurada com 4 neurônios na camada intermediária, taxa de aprendizado de 0.2 e tolerância de erro de 0.001. Uma semente aleatória (seed=42) foi utilizada para garantir a reprodutibilidade dos resultados.

### 7.1. Resultados do Treinamento XOR

O treinamento da rede para a função XOR resultou em:

-   **Épocas até Convergência:** 8360
-   **Erro Final (MSE):** 0.001000

Os resultados finais da rede para as entradas XOR foram:

| Entrada | Saída Prevista | Saída Esperada |
| :------ | :------------- | :------------- |
| [0, 0]  | 0.0280         | 0              |
| [0, 1]  | 0.9663         | 1              |
| [1, 0]  | 0.9690         | 1              |
| [1, 1]  | 0.0334         | 0              |

Os valores previstos estão próximos dos valores esperados, indicando que a rede aprendeu a função XOR com sucesso.

### 7.2. Gráfico Erro x Época (XOR)

O gráfico a seguir ilustra a diminuição do erro quadrático médio ao longo das épocas de treinamento para a função XOR:

![Gráfico Erro x Época (XOR)](https://private-us-east-1.manuscdn.com/sessionFile/YccXVbaseyg0xtKZ0sLnsZ/sandbox/L8IDgrpb9ttvYE8i9KI87S-images_1781123721682_na1fn_L2hvbWUvdWJ1bnR1L2Vycm9feG9y.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvWWNjWFZiYXNleWcweHRLWjBzTG5zWi9zYW5kYm94L0w4SURncnBiOXR0dllFOGk5S0k4N1MtaW1hZ2VzXzE3ODExMjM3MjE2ODJfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyVnljbTlmZUc5eS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=vYsCnhXwGON1JTfxuvt9iBhKU2sD1W1bp2hkUselb887wrGYw2S3BloMZdgasDuvoh2qFkI3zPWXDPUmLSxxw3U8ZyQZnJ~7odUs1YsPj7pcXs2FMmqveH-UQwlSBaNeAk6qPjaaPqCDS27Usj9x2FR3CkEWPPpmkschlhYrjoTYkWTVHmnOkghW7Xb6dl402wRj3Xspw6~wxODGjhfng1KWSgvF~vABDCc8WrKjlrAY0gT3vVcgSrbUTn7d5Pk-tJPJGAkmvCC99MzC2iBsWpgjfu3ja1bsE766TMoinnSP5XnMU4O7JfsipmR87p2KWbfFT6tyIDU~UyLB3Y5i6w__)

## 8. Experimentos Adicionais

Foram realizados três experimentos adicionais para analisar o impacto de diferentes parâmetros no desempenho da rede neural.

### 8.1. Experimento A – Quantidade de Neurônios na Camada Intermediária

Este experimento avaliou o impacto da quantidade de neurônios na camada intermediária (2, 3, 4 e 5 neurônios) no número de épocas necessárias para a convergência e no erro final. A taxa de aprendizado foi fixada em 0.2 e a semente em 42.

| Neurônios | Épocas | Erro Final |
| :-------- | :----- | :--------- |
| 2         | 10000  | 0.001007   |
| 3         | 7981   | 0.001000   |
| 4         | 8360   | 0.001000   |
| 5         | 9383   | 0.001000   |

**Análise:** Observa-se que com 2 neurônios, a rede não atingiu a tolerância de erro dentro do limite de épocas, indicando que uma camada intermediária muito pequena pode não ser suficiente para aprender a função XOR. Com 3, 4 e 5 neurônios, a rede converge para o erro tolerado, com pequenas variações no número de épocas.

### 8.2. Experimento B – Taxa de Aprendizagem

Este experimento investigou a influência da taxa de aprendizado (0.1, 0.2, 0.3, 0.4, 0.5) no treinamento da rede. A quantidade de neurônios na camada intermediária foi fixada em 4 e a semente em 42.

| Taxa de Aprendizado | Épocas | Erro Final |
| :------------------ | :----- | :--------- |
| 0.1                 | 10000  | 0.002132   |
| 0.2                 | 8360   | 0.001000   |
| 0.3                 | 5574   | 0.001000   |
| 0.4                 | 4181   | 0.001000   |
| 0.5                 | 3345   | 0.001000   |

**Análise:** Uma taxa de aprendizado muito baixa (0.1) resultou em um número máximo de épocas atingido sem convergência para o erro tolerado. À medida que a taxa de aprendizado aumenta, o número de épocas para convergência diminui significativamente, indicando um aprendizado mais rápido. No entanto, taxas muito altas podem levar a instabilidade e não convergência (não observado neste intervalo).

### 8.3. Experimento C – Influência da Inicialização dos Pesos

Este experimento analisou como diferentes inicializações aleatórias dos pesos afetam o treinamento. Foram utilizadas 5 sementes aleatórias (0, 1, 2, 3, 4) para a inicialização, mantendo 4 neurônios na camada intermediária e taxa de aprendizado de 0.2.

| Seed | Épocas | Erro Final |
| :--- | :----- | :--------- |
| 0    | 6920   | 0.001000   |
| 1    | 9051   | 0.001000   |
| 2    | 8309   | 0.001000   |
| 3    | 9280   | 0.001000   |
| 4    | 7730   | 0.001000   |

**Análise:** Embora todas as sementes tenham levado à convergência para o erro tolerado, o número de épocas variou consideravelmente. Isso demonstra que a inicialização dos pesos pode influenciar a trajetória de aprendizado da rede, afetando a velocidade de convergência, mas não necessariamente a capacidade final de aprendizado para este problema.

## 9. Discussão dos Resultados

### 9.1. Qual configuração apresentou a convergência mais rápida?

A configuração com **taxa de aprendizado de 0.5** (no Experimento B) apresentou a convergência mais rápida, com 3345 épocas.

### 9.2. O aumento do número de neurônios sempre reduziu o número de épocas?

Não. No Experimento A, o aumento de 3 para 4 e de 4 para 5 neurônios na camada intermediária resultou em um aumento no número de épocas (de 7981 para 8360 e depois para 9383, respectivamente). Isso sugere que, após um certo ponto, adicionar mais neurônios pode não necessariamente acelerar a convergência e pode até introduzir mais complexidade que o algoritmo leva mais tempo para otimizar.

### 9.3. Como a taxa de aprendizagem influenciou o treinamento?

A taxa de aprendizagem teve uma influência significativa. Taxas mais baixas (0.1) resultaram em um aprendizado muito lento, não atingindo a tolerância de erro dentro do limite de épocas. Taxas mais altas (0.2 a 0.5) aceleraram a convergência, reduzindo o número de épocas necessárias para atingir o erro tolerado. Uma taxa de aprendizado adequada é crucial para um treinamento eficiente, evitando tanto a lentidão excessiva quanto a instabilidade.

### 9.4. A inicialização dos pesos afetou os resultados?

Sim, a inicialização dos pesos afetou o número de épocas necessárias para a convergência. Embora todas as diferentes sementes aleatórias tenham permitido que a rede convergisse para o erro tolerado, o caminho para essa convergência (ou seja, o número de épocas) variou. Isso ressalta a importância de uma boa estratégia de inicialização ou de múltiplas execuções com diferentes inicializações para encontrar um treinamento mais eficiente.

### 9.5. Os resultados obtidos foram compatíveis com os apresentados no artigo?

Considerando que o 
roteiro não forneceu um artigo base específico com resultados para comparação direta, a compatibilidade foi avaliada com base na expectativa geral de comportamento de redes neurais treinadas com backpropagation para o problema XOR. Os resultados obtidos (convergência para o erro tolerado, impacto da taxa de aprendizado e da inicialização dos pesos) são consistentes com a literatura e o comportamento esperado para este tipo de rede e problema.

### 9.6. Quais fatores podem explicar eventuais diferenças observadas?

Eventuais diferenças nos resultados, especialmente no número de épocas para convergência, podem ser explicadas por:

-   **Inicialização Aleatória dos Pesos:** Pequenas variações nos valores iniciais dos pesos podem levar a diferentes trajetórias no espaço de busca da função de custo, resultando em diferentes números de épocas para atingir a convergência.
-   **Parâmetros de Treinamento:** A escolha da taxa de aprendizado e da tolerância de erro influencia diretamente a velocidade e a precisão da convergência.
-   **Arquitetura da Rede:** O número de neurônios na camada oculta afeta a capacidade da rede de modelar a complexidade do problema. Uma arquitetura subdimensionada pode não convergir, enquanto uma superdimensionada pode levar mais tempo para treinar ou ser mais suscetível a overfitting (embora menos relevante para o problema XOR).

## 10. Desafio Opcional

Utilizando a mesma implementação desenvolvida para o XOR, a rede foi treinada para aprender as funções lógicas AND, OR, NAND e NOR. A configuração utilizada foi de 4 neurônios na camada intermediária, taxa de aprendizado de 0.2 e semente 42.

| Função | Épocas | Erro Final |
| :----- | :----- | :--------- |
| AND    | 3926   | 0.001000   |
| OR     | 2700   | 0.001000   |
| NAND   | 4096   | 0.001000   |
| NOR    | 2731   | 0.001000   |

**Comparação com a função XOR:**

As funções AND, OR, NAND e NOR são linearmente separáveis, o que geralmente as torna mais fáceis de aprender para uma rede neural em comparação com a função XOR, que é não-linearmente separável. Os resultados mostram que, de fato, a rede converge para essas funções com um número significativamente menor de épocas em comparação com o XOR (8360 épocas). Isso reforça a compreensão de que a complexidade do problema (linearmente separável vs. não-linearmente separável) tem um impacto direto na dificuldade de aprendizado da rede neural.

## 11. Código Completo

O código completo da implementação da rede neural MLP e do algoritmo Backpropagation, incluindo as funções de ativação, o treinamento para XOR e os experimentos adicionais, está disponível no arquivo `mlp_backpropagation.py`.

## 12. Referências

[1] Roteiro para o trabalho 2 - Google Docs. Disponível em: [https://docs.google.com/document/d/12WRhflmlIQ-Yvrk-g5nzBQfuh10Edg1sf07V50kgRQ4/edit?tab=t.towtuaaui4hk#heading=h.z9rv06m7zd7c](https://docs.google.com/document/d/12WRhflmlIQ-Yvrk-g5nzBQfuh10Edg1sf07V50kgRQ4/edit?tab=t.towtuaaui4hk#heading=h.z9rv06m7zd7c)
