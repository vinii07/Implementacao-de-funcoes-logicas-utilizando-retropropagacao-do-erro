# Requisitos do Trabalho 2 - Redes Neurais e Backpropagation

## Objetivos
Prática com MLP e algoritmo Backpropagation através da reprodução de experimentos.

## Estrutura do Trabalho
1. **Análise do Problema (XOR)**:
   - Representação em plano cartesiano.
   - Explicação sobre fronteira linear e necessidade de camada intermediária.
2. **Preparação do Ambiente**:
   - Bibliotecas: `numpy`, `matplotlib`.
3. **Funções de Ativação**:
   - Sigmóide binária: $f(x) = \frac{1}{1+e^{-x}}$
   - Sigmóide bipolar: $f(x) = \frac{2}{1+e^{-x}} - 1$
   - Tangente Hiperbólica.
   - Gerar gráficos destas funções.
4. **Implementação da Rede MLP**:
   - 2 neurônios de entrada, 1 camada intermediária, 1 neurônio de saída.
   - Configuração inicial: 4 neurônios na camada intermediária, taxa de aprendizado 0.2, tolerância 0.001.
5. **Algoritmo Backpropagation**:
   - Forward: Ativações e saída.
   - Backward: Cálculo de erro, propagação e atualização de pesos/bias.
6. **Experimento XOR**:
   - Padrões: X = [[0,0], [0,1], [1,0], [1,1]], Y = [[0], [1], [1], [0]].
   - Registro: Erro por época, erro absoluto total, épocas até convergência.
   - Gráfico Erro x Época.
7. **Experimentos Adicionais**:
   - **A (Neurônios)**: Testar 2, 3, 4 e 5 neurônios na camada intermediária.
   - **B (Taxa de Aprendizado)**: Fixar 4 neurônios e testar taxas 0.1, 0.2, 0.3, 0.4, 0.5.
   - **C (Inicialização)**: Executar 5 vezes com sementes diferentes (np.random.seed).
8. **Discussão dos Resultados**:
   - Responder perguntas sobre convergência, impacto de parâmetros e inicialização.
9. **Desafio Opcional**:
   - Treinar para AND, OR, NAND, NOR e comparar.

## Formatação
- Texto científico formal.
- Dividido pelas seções do roteiro.
