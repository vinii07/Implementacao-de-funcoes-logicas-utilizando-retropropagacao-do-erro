# MLP Backpropagation - Implementação de Funções Lógicas

Este projeto consiste na implementação de uma Rede Neural do tipo Perceptron Multicamadas (MLP) treinada através do algoritmo de Retropropagação do Erro (Backpropagation) para resolver funções lógicas clássicas, como XOR, AND, OR, NAND e NOR.

O trabalho foi desenvolvido seguindo rigorosamente os requisitos acadêmicos de modelagem, implementação e análise experimental.

## 🚀 Estrutura do Projeto

- `mlp_gui.py`: **Interface Gráfica (GUI)** completa para configurar, treinar e testar a rede neural visualmente.
- `mlp_backpropagation.py`: Script focado em experimentos via terminal e geração de gráficos estáticos.
- `trabalho_final.pdf`: Documento acadêmico completo com fundamentação teórica e discussão dos resultados.
- `trabalho_final.md`: Versão em Markdown do documento acadêmico.
- `funcoes_ativacao.png`: Gráficos das funções Sigmóide Binária, Bipolar e Tangente Hiperbólica.
- `erro_xor.png`: Gráfico da evolução do erro (MSE) durante o treinamento da função XOR.

## 🛠️ Pré-requisitos

Para executar o código, você precisará do Python 3 instalado e das seguintes bibliotecas:

- **NumPy**: Para operações matriciais e cálculos numéricos.
- **Matplotlib**: Para geração de gráficos.

Você pode instalar as dependências necessárias utilizando o comando:

```bash
pip install numpy matplotlib
```

## 💻 Como Utilizar

1. **Interface Gráfica (Recomendado):**
   Para utilizar a interface visual conforme solicitado no roteiro (configuração de parâmetros, botões de teste e gráficos em tempo real), execute:

   ```bash
   python mlp_gui.py
   ```

2. **Execução via Terminal:**
   Para rodar os experimentos automatizados e gerar os gráficos para o relatório:

   ```bash
   python mlp_backpropagation.py
   ```

2. **Resultados no Console:**
   O script exibirá no terminal:
   - O progresso e resultados finais da função XOR.
   - Tabelas comparativas do impacto do número de neurônios na camada oculta.
   - O efeito de diferentes taxas de aprendizado na convergência.
   - A influência da inicialização dos pesos (sementes).
   - O desempenho da rede para outras funções lógicas (AND, OR, NAND, NOR).

3. **Arquivos Gerados:**
   Após a execução, o script salvará automaticamente as imagens `funcoes_ativacao.png` e `erro_xor.png` no diretório atual.

## 🧠 Detalhes Técnicos

A rede foi modelada com:
- **Camada de Entrada:** 2 neurônios (para as entradas lógicas A e B).
- **Camada Oculta:** Configurável (padrão de 4 neurônios).
- **Camada de Saída:** 1 neurônio.
- **Função de Ativação:** Sigmóide Binária (com suporte implementado para Bipolar e Tanh).
- **Algoritmo:** Gradiente Descendente com Backpropagation.

## 📚 Referências

Este projeto foi desenvolvido como parte das atividades práticas de Inteligência Artificial, baseando-se no roteiro de trabalho disponível no Google Docs do curso.
