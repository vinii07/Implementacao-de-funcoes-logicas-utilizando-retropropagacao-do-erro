import numpy as np
import matplotlib.pyplot as plt

# --- Parte 3: Implementação das funções de ativação ---

def sigmoid(x):
    """Função Sigmóide Binária."""
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    """Derivada da Função Sigmóide Binária."""
    return x * (1 - x)

def sigmoid_bipolar(x):
    """Função Sigmóide Bipolar."""
    return (2 / (1 + np.exp(-x))) - 1

def sigmoid_bipolar_derivative(x):
    """Derivada da Função Sigmóide Bipolar."""
    return 0.5 * (1 - x**2)

def tanh(x):
    """Função Tangente Hiperbólica."""
    return np.tanh(x)

def tanh_derivative(x):
    """Derivada da Função Tangente Hiperbólica."""
    return 1 - x**2

def plot_activation_functions():
    """Gera gráficos das funções de ativação."""
    x = np.linspace(-10, 10, 100)
    
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 3, 1)
    plt.plot(x, sigmoid(x))
    plt.title('Sigmóide Binária')
    plt.grid(True)
    
    plt.subplot(1, 3, 2)
    plt.plot(x, sigmoid_bipolar(x))
    plt.title('Sigmóide Bipolar')
    plt.grid(True)
    
    plt.subplot(1, 3, 3)
    plt.plot(x, tanh(x))
    plt.title('Tangente Hiperbólica')
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('funcoes_ativacao.png')
    plt.close()

# --- Parte 4 & 5: Implementação da rede MLP e Backpropagation ---

class MLP:
    def __init__(self, input_size=2, hidden_size=4, output_size=1, learning_rate=0.2, tolerance=0.001, seed=None):
        if seed is not None:
            np.random.seed(seed)
            
        self.learning_rate = learning_rate
        self.tolerance = tolerance
        
        # Inicialização de pesos e bias
        self.weights_input_hidden = np.random.uniform(-1, 1, (input_size, hidden_size))
        self.bias_hidden = np.random.uniform(-1, 1, (1, hidden_size))
        
        self.weights_hidden_output = np.random.uniform(-1, 1, (hidden_size, output_size))
        self.bias_output = np.random.uniform(-1, 1, (1, output_size))
        
    def forward(self, X):
        """Fase Forward."""
        # Camada Oculta
        self.hidden_input = np.dot(X, self.weights_input_hidden) + self.bias_hidden
        self.hidden_output = sigmoid(self.hidden_input)
        
        # Camada de Saída
        self.final_input = np.dot(self.hidden_output, self.weights_hidden_output) + self.bias_output
        self.final_output = sigmoid(self.final_input)
        
        return self.final_output
    
    def backward(self, X, y, output):
        """Fase Backward e Atualização de Pesos."""
        # Erro na camada de saída
        error_output = y - output
        delta_output = error_output * sigmoid_derivative(output)
        
        # Erro na camada oculta (propagado de volta)
        error_hidden = delta_output.dot(self.weights_hidden_output.T)
        delta_hidden = error_hidden * sigmoid_derivative(self.hidden_output)
        
        # Atualização dos pesos e bias
        self.weights_hidden_output += self.hidden_output.T.dot(delta_output) * self.learning_rate
        self.bias_output += np.sum(delta_output, axis=0, keepdims=True) * self.learning_rate
        
        self.weights_input_hidden += X.T.dot(delta_hidden) * self.learning_rate
        self.bias_hidden += np.sum(delta_hidden, axis=0, keepdims=True) * self.learning_rate
        
    def train(self, X, y, max_epochs=10000):
        """Treinamento da rede."""
        epoch_errors = []
        for epoch in range(max_epochs):
            output = self.forward(X)
            self.backward(X, y, output)
            
            # Cálculo do erro absoluto total (MSE simplificado para monitoramento)
            error = np.mean(np.square(y - output))
            epoch_errors.append(error)
            
            if error <= self.tolerance:
                break
                
        return epoch_errors, epoch + 1

# --- Parte 6: Reprodução do experimento XOR ---

def run_xor_experiment():
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([[0], [1], [1], [0]])
    
    mlp = MLP(input_size=2, hidden_size=4, output_size=1, learning_rate=0.2, tolerance=0.001, seed=42)
    errors, epochs = mlp.train(X, y)
    
    print(f"Treinamento XOR concluído em {epochs} épocas.")
    print("Resultados Finais:")
    final_output = mlp.forward(X)
    for i in range(len(X)):
        print(f"Entrada: {X[i]} -> Saída Prevista: {final_output[i][0]:.4f} (Esperado: {y[i][0]})")
    
    plt.figure()
    plt.plot(errors)
    plt.title('Erro x Época (XOR)')
    plt.xlabel('Época')
    plt.ylabel('Erro (MSE)')
    plt.grid(True)
    plt.savefig('erro_xor.png')
    plt.close()
    
    return epochs, errors[-1]

# --- Parte 7: Experimentos Adicionais ---

def experiment_neurons():
    """Experimento A – Quantidade de neurônios na camada intermediária."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([[0], [1], [1], [0]])
    neurons = [2, 3, 4, 5]
    results = []
    
    for n in neurons:
        mlp = MLP(hidden_size=n, seed=42)
        errors, epochs = mlp.train(X, y)
        results.append((n, epochs, errors[-1]))
        
    print("\nExperimento A - Neurônios:")
    print("Neurônios | Épocas | Erro Final")
    for r in results:
        print(f"{r[0]:9} | {r[1]:6} | {r[2]:.6f}")
    return results

def experiment_learning_rate():
    """Experimento B – Taxa de aprendizagem."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([[0], [1], [1], [0]])
    rates = [0.1, 0.2, 0.3, 0.4, 0.5]
    results = []
    
    for lr in rates:
        mlp = MLP(hidden_size=4, learning_rate=lr, seed=42)
        errors, epochs = mlp.train(X, y)
        results.append((lr, epochs, errors[-1]))
        
    print("\nExperimento B - Taxa de Aprendizado:")
    print("Taxa | Épocas | Erro Final")
    for r in results:
        print(f"{r[0]:4.1f} | {r[1]:6} | {r[2]:.6f}")
    return results

def experiment_initialization():
    """Experimento C – Influência da inicialização dos pesos."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    y = np.array([[0], [1], [1], [0]])
    seeds = [0, 1, 2, 3, 4]
    results = []
    
    for s in seeds:
        mlp = MLP(hidden_size=4, seed=s)
        errors, epochs = mlp.train(X, y)
        results.append((s, epochs, errors[-1]))
        
    print("\nExperimento C - Inicialização (Sementes):")
    print("Seed | Épocas | Erro Final")
    for r in results:
        print(f"{r[0]:4} | {r[1]:6} | {r[2]:.6f}")
    return results

# --- Desafio Opcional ---

def run_challenge():
    """Treina para AND, OR, NAND, NOR."""
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    functions = {
        "AND": np.array([[0], [0], [0], [1]]),
        "OR": np.array([[0], [1], [1], [1]]),
        "NAND": np.array([[1], [1], [1], [0]]),
        "NOR": np.array([[1], [0], [0], [0]])
    }
    
    print("\nDesafio Opcional - Outras Funções Lógicas:")
    for name, y in functions.items():
        mlp = MLP(hidden_size=4, seed=42)
        errors, epochs = mlp.train(X, y)
        print(f"Função {name:4}: {epochs:5} épocas, Erro Final: {errors[-1]:.6f}")

if __name__ == "__main__":
    plot_activation_functions()
    run_xor_experiment()
    experiment_neurons()
    experiment_learning_rate()
    experiment_initialization()
    run_challenge()
