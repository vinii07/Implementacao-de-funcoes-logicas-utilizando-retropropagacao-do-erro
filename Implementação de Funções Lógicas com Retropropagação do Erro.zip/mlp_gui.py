import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import ttk, messagebox

# --- Lógica da Rede Neural (Baseada na implementação anterior) ---

class MLP:
    def __init__(self, input_size=2, hidden_size=4, output_size=1, learning_rate=0.2, tolerance=0.001, activation='binaria'):
        self.learning_rate = learning_rate
        self.tolerance = tolerance
        self.activation_type = activation
        
        # Inicialização de pesos e bias
        self.weights_input_hidden = np.random.uniform(-1, 1, (input_size, hidden_size))
        self.bias_hidden = np.random.uniform(-1, 1, (1, hidden_size))
        
        self.weights_hidden_output = np.random.uniform(-1, 1, (hidden_size, output_size))
        self.bias_output = np.random.uniform(-1, 1, (1, output_size))
        
    def _activate(self, x):
        if self.activation_type == 'binaria':
            return 1 / (1 + np.exp(-x))
        else: # bipolar
            return (2 / (1 + np.exp(-x))) - 1
            
    def _derivative(self, x):
        if self.activation_type == 'binaria':
            return x * (1 - x)
        else: # bipolar
            return 0.5 * (1 - x**2)

    def forward(self, X):
        self.hidden_input = np.dot(X, self.weights_input_hidden) + self.bias_hidden
        self.hidden_output = self._activate(self.hidden_input)
        self.final_input = np.dot(self.hidden_output, self.weights_hidden_output) + self.bias_output
        self.final_output = self._activate(self.final_input)
        return self.final_output
    
    def backward(self, X, y, output):
        error_output = y - output
        delta_output = error_output * self._derivative(output)
        
        error_hidden = delta_output.dot(self.weights_hidden_output.T)
        delta_hidden = error_hidden * self._derivative(self.hidden_output)
        
        self.weights_hidden_output += self.hidden_output.T.dot(delta_output) * self.learning_rate
        self.bias_output += np.sum(delta_output, axis=0, keepdims=True) * self.learning_rate
        
        self.weights_input_hidden += X.T.dot(delta_hidden) * self.learning_rate
        self.bias_hidden += np.sum(delta_hidden, axis=0, keepdims=True) * self.learning_rate

# --- Interface Gráfica (GUI) ---

class MLPApp:
    def __init__(self, root):
        self.root = root
        self.root.title("MLP - Implementação de Funções Lógicas")
        self.root.geometry("900x650")
        
        self.mlp = None
        self.training_data = {
            "XOR": (np.array([[0,0], [0,1], [1,0], [1,1]]), np.array([[0], [1], [1], [0]])),
            "AND": (np.array([[0,0], [0,1], [1,0], [1,1]]), np.array([[0], [0], [0], [1]])),
            "OR":  (np.array([[0,0], [0,1], [1,0], [1,1]]), np.array([[0], [1], [1], [1]]))
        }
        
        self._setup_ui()
        
    def _setup_ui(self):
        # Frame de Configuração (Esquerda)
        config_frame = ttk.LabelFrame(self.root, text="Configuração do Treinamento", padding=10)
        config_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)
        
        ttk.Label(config_frame, text="Função Lógica:").pack(anchor=tk.W)
        self.func_var = tk.StringVar(value="XOR")
        ttk.Combobox(config_frame, textvariable=self.func_var, values=["XOR", "AND", "OR"], state="readonly").pack(fill=tk.X, pady=5)
        
        ttk.Label(config_frame, text="Neurônios Camada Oculta:").pack(anchor=tk.W)
        self.hidden_var = tk.IntVar(value=4)
        ttk.Entry(config_frame, textvariable=self.hidden_var).pack(fill=tk.X, pady=5)
        
        ttk.Label(config_frame, text="Taxa de Aprendizado:").pack(anchor=tk.W)
        self.lr_var = tk.DoubleVar(value=0.2)
        ttk.Entry(config_frame, textvariable=self.lr_var).pack(fill=tk.X, pady=5)
        
        ttk.Label(config_frame, text="Tolerância de Erro:").pack(anchor=tk.W)
        self.tol_var = tk.DoubleVar(value=0.001)
        ttk.Entry(config_frame, textvariable=self.tol_var).pack(fill=tk.X, pady=5)
        
        ttk.Label(config_frame, text="Máximo de Épocas:").pack(anchor=tk.W)
        self.epochs_var = tk.IntVar(value=10000)
        ttk.Entry(config_frame, textvariable=self.epochs_var).pack(fill=tk.X, pady=5)
        
        ttk.Label(config_frame, text="Função de Ativação:").pack(anchor=tk.W)
        self.activation_var = tk.StringVar(value="binaria")
        ttk.Radiobutton(config_frame, text="Sigmóide Binária", variable=self.activation_var, value="binaria").pack(anchor=tk.W)
        ttk.Radiobutton(config_frame, text="Sigmóide Bipolar", variable=self.activation_var, value="bipolar").pack(anchor=tk.W)
        
        self.train_btn = ttk.Button(config_frame, text="Treinar Rede", command=self.train_network)
        self.train_btn.pack(fill=tk.X, pady=20)
        
        # Frame de Teste (Abaixo da Configuração)
        test_frame = ttk.LabelFrame(config_frame, text="Teste da Rede", padding=10)
        test_frame.pack(fill=tk.X, pady=10)
        
        self.in1_var = tk.IntVar(value=0)
        self.in2_var = tk.IntVar(value=0)
        ttk.Checkbutton(test_frame, text="Entrada 1", variable=self.in1_var).pack(anchor=tk.W)
        ttk.Checkbutton(test_frame, text="Entrada 2", variable=self.in2_var).pack(anchor=tk.W)
        
        ttk.Button(test_frame, text="Calcular Saída", command=self.test_network).pack(fill=tk.X, pady=5)
        self.result_label = ttk.Label(test_frame, text="Resultado: -", font=("Arial", 10, "bold"))
        self.result_label.pack(pady=5)
        
        # Frame de Visualização (Direita)
        viz_frame = ttk.Frame(self.root, padding=10)
        viz_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        self.fig, self.ax = plt.subplots(figsize=(5, 4))
        self.ax.set_title("Gráfico de Erro")
        self.ax.set_xlabel("Época")
        self.ax.set_ylabel("MSE")
        self.canvas = FigureCanvasTkAgg(self.fig, master=viz_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.status_label = ttk.Label(viz_frame, text="Status: Aguardando treinamento...")
        self.status_label.pack(pady=5)

    def train_network(self):
        try:
            X, y = self.training_data[self.func_var.get()]
            
            # Ajustar y se for bipolar
            if self.activation_var.get() == 'bipolar':
                y_train = np.where(y == 0, -1, 1)
            else:
                y_train = y
                
            self.mlp = MLP(
                hidden_size=self.hidden_var.get(),
                learning_rate=self.lr_var.get(),
                tolerance=self.tol_var.get(),
                activation=self.activation_var.get()
            )
            
            errors = []
            max_epochs = self.epochs_var.get()
            
            for epoch in range(max_epochs):
                output = self.mlp.forward(X)
                self.mlp.backward(X, y_train, output)
                
                mse = np.mean(np.square(y_train - output))
                errors.append(mse)
                
                if mse <= self.mlp.tolerance:
                    break
            
            # Atualizar Gráfico
            self.ax.clear()
            self.ax.plot(errors, color='blue')
            self.ax.set_title(f"Treinamento {self.func_var.get()}")
            self.ax.set_xlabel("Época")
            self.ax.set_ylabel("MSE")
            self.ax.grid(True)
            self.canvas.draw()
            
            self.status_label.config(text=f"Status: Convergiu em {len(errors)} épocas. Erro: {mse:.6f}")
            messagebox.showinfo("Sucesso", f"Treinamento concluído!\nÉpocas: {len(errors)}\nErro Final: {mse:.6f}")
            
        except Exception as e:
            messagebox.showerror("Erro", f"Falha no treinamento: {str(e)}")

    def test_network(self):
        if self.mlp is None:
            messagebox.showwarning("Aviso", "Treine a rede primeiro!")
            return
            
        x_test = np.array([[self.in1_var.get(), self.in2_var.get()]])
        output = self.mlp.forward(x_test)[0][0]
        
        # Interpretação do resultado
        if self.activation_var.get() == 'bipolar':
            pred = 1 if output > 0 else 0
        else:
            pred = 1 if output > 0.5 else 0
            
        self.result_label.config(text=f"Resultado: {pred} (Bruto: {output:.4f})")

if __name__ == "__main__":
    root = tk.Tk()
    app = MLPApp(root)
    root.mainloop()
